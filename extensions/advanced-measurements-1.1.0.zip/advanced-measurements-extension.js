"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const extension = {
    measurementFunctions: [
        {
            id: "rms",
            name: "RMS",
            script: "rms.js"
        }
    ]
};
exports.default = extension;
